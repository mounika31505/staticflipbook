const siteConfig = {
    header:{
        title1:`Edumania`,
        description1:`--------World's Biggest Universety--------` ,
        description:` Ignite Your Learning Journey with Innovation and Excellence.`,
        link:{
            text:`Vist Us To know More`,
            type:`link`,
            target:`self`,
            extra:{
                className:`hero-btn`
            }
        }
    }
}
export {siteConfig}
// `making website is one of the easiest thing in the world
//         just need to learn HTML,CSS and Javascript and you are good to go.`