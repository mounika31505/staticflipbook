import about from "../assets/images/about.jpg";
import logo from "../assets/images/logo.png";
import banner from "../assets/images/banner.png";
import london from "../assets/images/london.png";
import newyork from "../assets/images/newyork.png";
import washingtion from "../assets/images/washington.png";
import library from "../assets/images/library.png";
import basketbal from "../assets/images/basketball.png";
import cafeteria from "../assets/images/cafeteria.png";
import user1 from "../assets/images/user1.jpg";
import user2 from "../assets/images/user2.jpg";
import banner2 from "../assets/images/banner2.jpg";
import background from "../assets/images/background.jpg";
import customer from "../assets/images/image 2.png"
import college from "../assets/images/Sewanee-1.jpg"
import logo2 from "../assets/images/em-initial-logo-linked-circle-monogram-vector-29216617-PhotoRoom.png-PhotoRoom.png"

export {

    about,
    logo2,
        logo,
    banner,
    london,
    newyork,
    washingtion,
    basketbal,
    cafeteria,
    library,
    user1,
    user2,
    banner2,background,
    customer,
    college
    

}