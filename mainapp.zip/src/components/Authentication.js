import React from 'react'

const Authentication = () => {
  return (
    <div>Authentication</div>
  )
}

export default Authentication