// .form-container{
//     /* background-color: rgb(141, 205, 205);  */
//    height: 100vh;
//    display: grid;
//    grid-template-columns: 40% 60%;
//    align-items: center;
//    justify-content: center;
//    flex-direction: column;
//    border: none;
//    text-decoration: none;
//    background-repeat: no-repeat;
 
//    font-family:Arial, Helvetica, sans-serif;
//    /* background:url("../assets/images/wp2940002-login-wallpaper.jpg");  */
  
//  }
//  .form-container h1{
//    align-items: center;
//  }
//  .left{
   
//    flex: 40%;
//    width: 100%;
//    height: auto;
  
//  }
//  .right{
//    flex: 60%;
//    align-items: center;
//    display: flex;
//  }
 
//  .form-container form {
//    width:100vh;
//    background-color:rgba(240, 255, 255, 0.253);
//    border-radius: 1rem;
//    padding-top:1rem;
//    padding-bottom: 4rem;
//    padding-left: 3rem;
//    padding-right: 3rem ;
//    box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;
//    /* box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px; */
//  }
//  .form-container form:hover{
//    box-shadow: 0 0 20px 0px rgba(0, 0, 0, 2);
//  }
//  .form-container form button{
//    cursor: pointer;
//    background-color: rgb(219, 231, 231);
//    color: black;
//    border-radius:5px;
//    padding: .5rem  1rem;
//    transition: .5s;
//    border-style: solid;
//    display: flex;
//  align-items: center;
//  }
//  .form-container form button:hover{
//  opacity: .9;
//  }
//  .form-container form button:active{
//    background-color: blue;
//  }
//  .form-container form input{
//    width: 100%;
//    padding: .6rem 0.2rem;
//    border-radius:10px;
//  }
//  .form-container form textarea{
//    width: 100%;
//    padding: .6rem 0.2rem;
//    border-radius:10px;
 
//  }