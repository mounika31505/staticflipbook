import React from 'react'

const Post = () => {
  return (
    <div>Post</div>
  )
}

export default Post