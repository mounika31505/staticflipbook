import React from 'react'

const Course = () => {
  return (
    <div className='course'>
        <h1>Course</h1>

        </div>
  )
}

export default Course