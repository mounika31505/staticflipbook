import React from 'react'
import { Link } from 'react-router-dom/cjs/react-router-dom'

const User = () => {
  return (
    <div>User
      <Link to="/login">Login</Link>
    </div>
  )
}

export default User


