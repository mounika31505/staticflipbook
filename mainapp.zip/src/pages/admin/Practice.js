import React, { useState } from 'react'

const Practice = () => {
  
    let arrvalue = [];
    for (let i=0; i<=5; i++)
     {
        console.log(i)
     }
  
}

export default Practice



