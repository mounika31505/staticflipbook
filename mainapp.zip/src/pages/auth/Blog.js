// import React from 'react'
// import "../../styles/Blog.css"


// const Blog = () => {
//   return (

//     <div  className="blog">

//       <h1 color=''>Blog</h1>
//       {/* <p>log<sub>2</sub><sup style={{marginLeft:"-4px"}}>3<sup>4</sup></sup></p> */}
//       <style>
    
//       </style>
//       <p>
//         <b>  Welcome to our<span style={{ color: 'red' }} University> </span> </b>, <em> to inspire and empower our <del>student</del> <ins>students</ins>.</em>
//         <br />
//         Founded on a<i style={{ color: 'green' }} ><mark> rich tradition</mark> </i>of<i style={{ color: 'green' }} ><mark>knowledge </mark> </i>and
//         <i style={{ color: 'green' }}> <mark>innovation </mark></i>,
//         our institution is dedicated to nurturing the talents of the
//         next generation <br />
//         With a diverse range of academic programs, dedicated faculty,
//         and a commitment to research and student success, we provide an environment
//         where you can explore, learn, and grow.</p>
//       <pre style={{ color: 'green' }}>
//         {`  Our campus is more than 

//     just a place of learning;

//         it's a home away from home. `}

//       </pre>
//       <p style={{ color: 'black' }} >From student organizations and
//         extracurricular activities to state-of-the-art research facilities
//         and<small> a welcoming residential life</small>.you'll find countless opportunities
//         to engage,connect, and thrive.Join us in shaping your future and
//         making a positive impact on the world Explore.
//         our website to discove the many facets of our academic community and
//         embark on an exciting journey of higher education with in our University.</p>

//       {/*----------------------<p>on exciting of higherr eduction in our company</p>----------------*/}

//       <a href="default.asp" img src="smiley.gif" alt="HTML tutorial" > </a>
//       <a href="https://www.w3schools.com/" target="_blank" rel="noreferrer">Visit W3Schools!</a>


//       <p>The area of a triangle is: 1/2 x <var>b</var> x <var>h</var>, where <var>b</var> is the base, and <var>h</var> is the vertical height.</p>
//       {/* <p>       
// You can specify background images<br />
// <b>for any visible HTML element.</b>
// <i>In this example, the background image</i>
// <del>is specified for a p element.</del>
// By default, the background-image<br/>
// will repeat itself in the direction(s)
// where it is smaller than the element
// where it is specified. (Try resizing) the<br/>
// browser window to see how the<br/>
// background image behaves.
// </p> */}



//       <ol type='I'>
//         <li>organization</li>
//         <li>facilities</li>
//         <li>activities</li>
//       </ol>


//       {/* <table>
//   <caption>
//     Alien football stars
//   </caption>
//   <tr>
//     <th scope="col">Player</th>
//     <th scope="col">Gloobles</th>
//     <th scope="col">Za'taak</th>
//   </tr>
//   <tr>
//     <th scope="row">TR-7</th>
//     <td>7</td>
//     <td>4,569</td>
//   </tr>
//   <tr>
//     <th scope="row">Khiresh Odo</th>
//     <td>7</td>
//     <td>7,223</td>
//   </tr>
//   <tr>
//     <th scope="row">Mia Oolong</th>
//     <td>9</td>
//     <td>6,219</td>
//   </tr>
// </table> */}
//     </div>


//   )
// }

// export default Blog;